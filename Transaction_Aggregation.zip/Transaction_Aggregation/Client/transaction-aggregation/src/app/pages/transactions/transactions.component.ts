import { Component, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatPaginator, PageEvent } from '@angular/material/paginator';

import { TransactionDto } from 'src/app/models/transaction';
import { TransactionService } from 'src/app/services/transaction.service';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-transactions',
  templateUrl: './transactions.component.html',
  styleUrls: ['./transactions.component.scss'],
  providers: [CommonModule],
})
export class TransactionsComponent {
  @ViewChild(MatPaginator) paginator: MatPaginator | null = null;
  transactions: TransactionDto[] = [];
  displayedColumns: string[] = [
    'bank',
    'category',
    'date',
    'amount',
    'description',
  ];
  dataSource = new MatTableDataSource<any>(this.transactions);
  currentPage = 1;
  totalTransactions = 0;
  totalValue = 0;
  startDate: string = '';
  endDate: string = '';
  category: string = '';
  page: number = 1;
  pageSize: number = 10;

  constructor(private transactionService: TransactionService) {}

  loadTransactions(): void {
    const start = this.startDate ? new Date(this.startDate).toISOString() : '';
    const end = this.endDate ? new Date(this.endDate).toISOString() : '';

    this.transactionService
      .getTransactions(start, end, this.category, this.currentPage, this.pageSize)
      .subscribe((data:any) => {
        this.transactions = data.transactions;
        this.totalTransactions = data.totalCount;
        this.totalValue = data.reduce((sum: any, tx: { amount: any; }) => sum + tx.amount, 0);
      });
  }
  onPageChange(event: PageEvent) {
    this.pageSize = event.pageSize;
    this.currentPage = event.pageIndex +1;
    this.loadTransactions();
  }
  ngAfterViewInit() {
    if (this.paginator) {
      this.dataSource.paginator = this.paginator;
    }
  }
}
