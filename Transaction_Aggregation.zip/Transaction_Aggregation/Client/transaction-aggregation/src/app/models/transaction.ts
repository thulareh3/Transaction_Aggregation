export interface TransactionDto {
  id: string;
  userId: number;
  bank: string;
  category: string;
  date: string;
  amount: number;
  description: string;
}

export interface TransactionResponse {
  transactions: TransactionDto[];
  totalAmount: number;
  totalCount: number; // optional, if you're paginating
}
