import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { TransactionDto } from '../models/transaction';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class TransactionService {
  api: any = 'http://localhost:5000/api/transactions';

  constructor(private http: HttpClient) {}

 getTransactions(
  startDate: string,
  endDate: string,
  category: string,
  page: number = 1,
  pageSize: number = 10
): Observable<TransactionDto[]> {
  const params = {
    startDate,
    endDate,
    category,
    page: page.toString(),
    pageSize: pageSize.toString()
  };

  return this.http.get<TransactionDto[]>(`${this.api}`, { params });
}

  createTransaction(dto: any) {
    return this.http.post(`${this.api}/create`, dto);
  }
}
