import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  api: any = 'http://localhost:5000/api/auth/';

  constructor(private http: HttpClient) {}

  login(credentials: { username: string; password: string }) {
    return this.http.post<{ token: string }>(`${this.api}login`, credentials);
  }

  setToken(token: string) {
    localStorage.setItem('token', token);
  }

  register(data: {
    username: string;
    password: string;
    role?: string;
  }): Observable<any> {
    return this.http.post(`${this.api}register`, data);
  }

  getToken(): string | null {
    return localStorage.getItem('token');
  }

  logout(): void {
    localStorage.removeItem('token');
  }

  isLoggedIn(): boolean {
    const token = localStorage.getItem('token');
    if (!token) return false;

    return !this.isTokenExpired(token);
  }

  isTokenExpired(token: string): boolean {
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      const expiry = payload.exp;
      return typeof expiry !== 'number' || expiry * 1000 < Date.now();
    } catch {
      return true;
    }
  }
}
