using Microsoft.EntityFrameworkCore;
using transaction_aggregation.Models;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public required DbSet<Transaction> Transactions { get; set; }
    public required DbSet<User> Users { get; set; }
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Transaction>()
            .Property(t => t.Amount)
            .HasPrecision(18, 2); 

        base.OnModelCreating(modelBuilder);
    }
}


