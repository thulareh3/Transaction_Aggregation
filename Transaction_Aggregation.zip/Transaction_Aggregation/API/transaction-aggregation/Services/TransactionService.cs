using System;
using System.Globalization;
using System.Security.Claims;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using transaction_aggregation.DTOS;
using transaction_aggregation.Interfaces;
using transaction_aggregation.Models;

namespace transaction_aggregation.Services;

public class TransactionService(AppDbContext context, IHttpContextAccessor httpContextAccessor) : ITransactionService
{
    private readonly AppDbContext _context = context;
    private readonly IHttpContextAccessor _httpContextAccessor = httpContextAccessor;

    public async Task<TransactionsWrapper<TransactionDto>> GetTransactionsFromRemoteAsync(
     DateTime startDate,
     DateTime endDate,
     string category,
     int page,
     int pageSize)
    {
        var userIdClaim = _httpContextAccessor?.HttpContext?.User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        int userId = int.TryParse(userIdClaim, out var id) ? id : 0;
        var role = _httpContextAccessor.HttpContext?.User.FindFirst(ClaimTypes.Role)?.Value;


        var httpClient = new HttpClient();
        var url = "https://raw.githubusercontent.com/thulareh3/transctions-server/main/db.json";

        var response = await httpClient.GetAsync(url);
        response.EnsureSuccessStatusCode();

        var json = await response.Content.ReadAsStringAsync();
        using var doc = JsonDocument.Parse(json);

        var wrapper = JsonSerializer.Deserialize<TransactionsWrapper<TransactionDto>>(json, new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        });

        var query = wrapper?.Transactions
     .Select(t =>
     {
         var success = DateTime.TryParseExact(
             t.Date,
             [
                "yyyy-MM-ddTHH:mm:ss.fffffffZ",
             ],
             CultureInfo.InvariantCulture,
             DateTimeStyles.AssumeUniversal,
             out var parsed
         );

         return new
         {
             Transaction = t,
             ParsedDate = success ? parsed : (DateTime?)null
         };
     })
     .Where(x => x.ParsedDate != null && x.ParsedDate >= startDate && x.ParsedDate <= endDate)
     .Select(x => x.Transaction);

        if (!string.IsNullOrEmpty(category) && category != "All")
        {
            query = query?.Where(t => t.Category == category);
        }
        if (role != "Admin")
        {
            query = query?.Where(x => x.UserId == userId);
        }
        int totalCount = query?.Count() ?? 0;

        var transactions = query?
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .Select(t => new TransactionDto
            {
                Id = t.Id,
                UserId = t.UserId,
                Bank = t.Bank,
                Category = t.Category,
                Date = t.Date,
                Amount = t.Amount,
                Description = t.Description
            })
            .ToList() ?? [];

        return new TransactionsWrapper<TransactionDto>
        {
            Transactions = transactions,
            TotalCount = totalCount
        };
    }

    public async Task<Transaction> CreateTransactionAsync(TransactionDto dto)
    {
        if (dto == null || string.IsNullOrWhiteSpace(dto.Bank) || dto.Amount <= 0)
        {
            throw new ArgumentException("Invalid transaction data.");
        }

        var transaction = new Transaction
        {
            Id = Guid.NewGuid(),
            Bank = dto.Bank,
            Category = dto.Category,
            Date = dto.Date,
            Amount = dto.Amount,
            Description = dto.Description
        };

        _context.Transactions.Add(transaction);
        await _context.SaveChangesAsync();

        return transaction;
    }
}

