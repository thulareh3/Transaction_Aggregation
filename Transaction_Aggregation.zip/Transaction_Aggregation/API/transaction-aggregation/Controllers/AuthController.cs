using Microsoft.AspNetCore.Mvc;
using transaction_aggregation.DTOS;
using transaction_aggregation.Helpers;
using transaction_aggregation.Models;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly AppDbContext _context;
    private readonly IConfiguration _config;

    public AuthController(AppDbContext context, IConfiguration config)
    {
        _context = context;
        _config = config;
    }

    [HttpPost("login")]
    public IActionResult Login([FromBody] LoginDto login)
    {
        var user = _context.Users.SingleOrDefault(u => u.Username == login.Username && u.Password == login.Password);
        if (user == null) return Unauthorized();

        var token = JwtHelper.GenerateToken(user, _config);
        return Ok(new { token });
    }
     [HttpPost("register")]
    public async Task<IActionResult> Register([FromBody] RegisterDto dto) {
        if (_context.Users.Any(u => u.Username == dto.Username)) {
            return BadRequest("Username already exists.");
        }

        var user = new User {
            Username = dto.Username,
            Password = dto.Password, // ⚠️ Hash this in production!
            Role = dto.Role
        };

        _context.Users.Add(user);
        await _context.SaveChangesAsync();

        return Ok("User registered successfully.");
    }
}
