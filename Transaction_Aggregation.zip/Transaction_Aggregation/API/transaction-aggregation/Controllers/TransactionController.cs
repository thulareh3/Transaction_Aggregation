using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using transaction_aggregation.DTOS;
using transaction_aggregation.Interfaces;
using transaction_aggregation.Models;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class TransactionsController(ITransactionService service) : ControllerBase
{
    private readonly ITransactionService _service = service;

    [HttpGet]
    public async Task<IActionResult> Get([FromQuery] DateTime startDate, [FromQuery] DateTime endDate, [FromQuery] string category, [FromQuery] int page = 1, [FromQuery] int pageSize = 10)
    {
        var result = await _service.GetTransactionsFromRemoteAsync(startDate, endDate, category, page, pageSize);
        return Ok(result);
    }
    [Authorize(Roles = "Admin")]
    [HttpPost("create")]
    public async Task<IActionResult> CreateTransaction([FromBody] TransactionDto dto)
    {
        try
        {
            var transaction = await _service.CreateTransactionAsync(dto);
            return Ok(new
            {
                message = "Transaction created successfully.",
                transactionId = transaction.Id
            });
        }
        catch (ArgumentException ex)
        {
            return BadRequest(ex.Message);
        }
    }
    [HttpGet("whoami")]
public IActionResult WhoAmI() {
    var claims = User.Claims.Select(c => new { c.Type, c.Value });
    return Ok(claims);
}

}

