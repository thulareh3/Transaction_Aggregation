using System;

namespace transaction_aggregation.DTOS;

public class TransactionsWrapper<T>
{
    public required List<TransactionDto> Transactions { get; set; } = [];
    public int TotalCount { get; set; }
}

public class TransactionResponse
{
    public required string Id { get; set; }
    public int UserId { get; set; }
    public decimal Amount { get; set; }
    public string Currency { get; set; }
    public required string Description { get; set; }
    public string Merchant { get; set; }
    public string Category { get; set; }
    public string Bank { get; set; }
}

public class TransactionDto
{
    public required string Id { get; set; }
    public int UserId { get; set; }
    public required string Bank { get; set; }
    public required string Category { get; set; }
    public decimal Amount { get; set; }
    public required string Description { get; set; }
    public required string Date { get; set; }
}

