using System;
using transaction_aggregation.DTOS;
using transaction_aggregation.Models;

namespace transaction_aggregation.Interfaces;

public interface ITransactionService
{
    Task<TransactionsWrapper<TransactionDto>> GetTransactionsFromRemoteAsync(
    DateTime startDate,
    DateTime endDate,
    string category,
    int page,
    int pageSize
);
    Task<Transaction> CreateTransactionAsync(TransactionDto dto);
}

