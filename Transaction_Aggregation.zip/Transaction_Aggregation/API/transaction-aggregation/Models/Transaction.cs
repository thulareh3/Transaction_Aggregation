namespace transaction_aggregation.Models;

public class Transaction
{
    public Guid Id { get; set; }
    public required string Bank { get; set; }
    public required string Category { get; set; }
    public string Date { get; set; }
    public decimal Amount { get; set; }
    public required string Description { get; set; }
}

